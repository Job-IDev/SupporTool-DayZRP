Thanks for using my tool.
To install you need to do the following steps:

==========================================================================================

Download chromedriver from this website:
https://chromedriver.chromium.org/downloads

Install it in a folder in your C:/ drive and add it to your path.

If you have problems adding items to your path follow this guide:
https://www.architectryan.com/2018/03/17/add-to-the-path-on-windows-10/

In order to make use of this tool you need to install python.
The tool was made in python 3.7 so anything above this will work.
https://www.python.org/downloads/

===========================================================================================

After you have downloaded python you need to start CMD.

Type in the following commands (hit enter after every line):

py -m pip install --user requests

py -m pip install --user beautifulsoup4

py -m pip install --user bs4

py -m pip install --user selenium

py -m pip install --user PySimpleGUI

============================================================================================

After this the installment is finished.

In order to use the tool without putting in your credentials anymore edit the "StaffTool.txt" file

Change username into your own username and password into your own password.

There is an option to leave this as it is, but it will require you to put in your credentials every time.

Now click and run the SupportTool.py file. This will make a console popup and start the program.

To use this fill in your username and your password in the console that popped up.

============================================================================================

Please do not move the pythonfile out of the original folder unless you move every file with it.

The pythonfile will otherwise not work.

============================================================================================

Disclaimer

This is just a tool to make your support work easier.

This tool is not perfect, so any bugs please report to JobScholten on the forums.

Putting in credentials in the StaffTool.txt file is at your own risk. There is no encription going on, so it will save your password in plain text.

I am very good at making a tutorial. If I missed some aspects/if it is still not working. Please send me a pm.