import requests
from bs4 import BeautifulSoup as bs
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
import PySimpleGUI as sg

sg.change_look_and_feel('SystemDefault')
layout = [[sg.Text('Thanks for using my StaffTool.\nThis tool was made by JobScholten.\nFor any problems contact me on the DayZRP forums.\n', justification='left')], [sg.Ok()]]
window = sg.Window('Thanks', layout)
event, values = window.read()
window.close()
credits = dict()
with open("StaffTool.txt") as file:
	for line in file:
		(key, val) = line.split()
		credits[key] = val
if credits['username'] == 'yourusernamehere':
	layout = [[sg.Text('Username', size=(15, 1)), sg.InputText('')],
	[sg.Submit()]]
	window = sg.Window('Simple data entry window').Layout(layout)         
	button, values = window.Read()
	window.close()
	credits['username'] = values[0]
if credits['password'] == 'yourpasswordhere':
	layout = [[sg.Text('Password', size=(15, 1)), sg.InputText('')],
	[sg.Submit()]]
	window = sg.Window('Simple data entry window').Layout(layout)         
	button, values = window.Read()
	window.close()
	credits['password'] = values[0]
def message(name, charactername, problems):
	message = ''
	message1 = f'Hey {name},\n\nThe staff team have looked over your character {charactername}.\nWe have found a few problems with your character.\n\n'
	message2 = 'If these changes have not been made within 48 hours, then you will be temporarily banned from the DayZRP server.\nIf you think your character does feel realistic, feel free to PM back and explain why.'
	messages = []
	for problem in problems:
		if problem == 'Date of birth':
			message3 = 'The current Date of birth would mean your character was born this week.\nWe do not allowe this and you would have to change this to a realistic Date of birth.\n\n'
			messages.append(message3)
		if problem == 'Picture':
			message4 = 'The Picture must represent your character.\nIt can only be a screenshot of your ingame character, or a real picture (from yourself or google).\nYou can however have other pictures as the second and third picture.\nYou would have to change your first picture to follow our guidelines.\n\n'
			messages.append(message4)
		if problem == 'Weight':
			message5 = 'The current weight does not meet our guidelines.\nThe weight of your character has to be somewhere between 50 and 150 kg.\nKeep in mind that kg is twice as much as pounds.\n\n'
			messages.append(message5)
		if problem == 'Height':
			message6 = 'The current height does not meet our guidelines.\nThe height of your character has to be somewhere between 150 and 200 cm.\n\n'
			messages.append(message6)
		if problem == 'Name':
			message7 = 'Your current character name does not meet our guidelines.\nThe name of your character should only be a first and last name.\nYou cannot use prefixes and all uppercase letters.\nThe only way to fix your character name is to delete your character and make a new one.\n\n'
			messages.append(message7)
	if len(problems) == 1:
		message = f'{message1}{messages[0]}{message2}'
	if len(problems) == 2:
		message = f'{message1}{messages[0]}Also,\n\n{messages[1]}{message2}'
	if len(problems) == 3:
		message = f'{message1}{messages[0]}Also,\n\n{messages[1]}Also,\n\n{messages[2]}{message2}'
	if len(problems) == 4:
		message = f'{message1}{messages[0]}Also,\n\n{messages[1]}Also,\n\n{messages[2]}Also,\n\n{messages[3]}{message2}'
	if len(problems) == 5:
		message = f'{message1}{messages[0]}Also,\n\n{messages[1]}Also,\n\n{messages[2]}Also,\n\n{messages[3]}Also,\n\n{messages[4]}{message2}'
	return message
with requests.Session() as s:
	list_of_links = []
	
	# Login Process
	url = "https://www.dayzrp.com/login/"
	driver = webdriver.Chrome()
	driver.get(url)
	driver.find_element_by_name("auth").send_keys(credits['username'])
	driver.find_element_by_name("password").send_keys(credits['password'])
	driver.find_element_by_name("_processLogin").click()
	username = credits['username']
	password = credits['password']
	remember_me = 0
	_processLogin = "usernamepassword"
	headers = {'User-Agent': 'Mozilla/5.0 (iPad; U; CPU OS 3_2_1 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Mobile/7B405'}
	site = s.get(url)
	bs_content = bs(site.content, "html.parser")
	token = bs_content.find("input", {"name":"csrfKey"})["value"]
	login_data = dict(csrfKey=token, auth=username, password=password, remember_me=remember_me, _processLogin=_processLogin)
	s.post(url ,data=login_data, headers=headers)
	
	# Search for the characters
	html = s.get("https://www.dayzrp.com/charactersmod/", headers=headers)
	soup = bs(html.text, "html.parser")
	containers = soup.findAll('tr')
	for container in containers:
		list_of_links.append((container.a['href'],container.a.text))
	value = []
	for i in list_of_links:
		value.append(i[1])
	layout = [[sg.Listbox(values=value, size=(30, 50))],[sg.Button('Select')]]
	window = sg.Window('Select Last Checked', layout)
	event, values = window.read()
	window.close()
	need_checking = []
	for name in list_of_links:
		if name[1] == values[0][0]:
			break
		else:
			need_checking.append(name)
	list_of_profiles = {}
	for profiles in need_checking:
		info = []
		i = 0
		driver.get(profiles[0])
		
		layout = [
		[sg.Text('Is the first picture correct?', justification='left')],
		[sg.Checkbox('Yes', size=(12, 1)), sg.Checkbox('No', size=(12, 1))],
		[sg.Text('Is the name correct?', justification='left')],
		[sg.Checkbox('Yes', size=(12, 1)), sg.Checkbox('No', size=(12, 1))],
		[sg.Text('Is the backstory correct?', justification='left')],
		[sg.Checkbox('Yes', size=(12, 1)), sg.Checkbox('No', size=(12, 1)), sg.Checkbox('WIP', size=(12, 1))],
		[sg.Ok()]]
		window = sg.Window('Check Page', layout)
		event, values = window.read()
		window.close()
		if values[0] == True:
			picturegood = 'yes'
		if values[1] == True:
			picturegood = 'no'
		if values[2] == True:
			namegood = 'yes'
		if values[3] == True:
			namegood = 'no'
		if values[4] == True:
			backstorygood = 'yes'
		if values[5] == True:
			backstorygood = 'no'
		if values[6] == True:
			backstorygood = 'wip'
		
		searchprof = s.get(profiles[0], headers=headers)
		showprof = bs(searchprof.text, 'html.parser')
		characterinfo = showprof.findAll('div', {'class':'ipsDataItem_generic'})
		description = showprof.findAll('div', {'class':'ipsDataItem_main'})
		title = showprof.findAll('div', {'class':'ipsType_pageTitle'})
		j = 0
		while j < len(characterinfo):
			texto = (characterinfo[j].text, description[j].text)
			if texto[0] == 'Date of birth':
				if len(texto[1]) == 10:
					i = 1
					info.append(texto)
			if texto[0] == 'Weight':
				if int(texto[1][0:len(texto[1])-3]) < 50 or int(texto[1][0:len(texto[1])-3]) > 150:
					i = 1
					info.append(texto)
			if texto[0] == 'Height':
				if int(texto[1][0:len(texto[1])-3]) < 150 or int(texto[1][0:len(texto[1])-3]) > 200:
					i = 1
					info.append(texto)
			j = j+1
		if namegood == 'no':
			info.append(('Name', 'no'))
			i = 1
		if picturegood == 'no':
			info.append(('Picture', 'no'))
			i = 1
		if backstorygood == 'wip':
			info.append(('Backstory', 'wip'))
			i = 1
		elif backstorygood == 'no':
			info.append(('Backstory', 'no'))
			i = 1
		if i == 0:
			continue
		else:
			profile_name = driver.find_element_by_class_name('ipsType_break').text
			driver.find_element_by_class_name('ipsType_break').click()
			profile_link = driver.current_url
			profile_id = driver.find_element_by_tag_name('body').get_attribute("data-pageid")
			info.append(('profile_link', profile_link))
			info.append(('character_link', profiles[0]))
			info.append(('profile_name', profile_name))
			info.append(('profile_id', int(profile_id)))
			list_of_profiles.update({title[0].text:info})
	leftovers = []
	open('InvalidCPList.txt', 'w').close()
	bericht = ''
	for everyone,reasons in list_of_profiles.items():
		character_name = everyone
		problems = []
		for reason in reasons:
			wip = 'no'
			if reason[0] == 'profile_name':
				name = reason[1]
			if reason[0] == 'profile_id':
				id = reason[1]
			if reason[0] == 'character_link':
				clink = reason[1]
			if reason[0] == 'profile_link':
				link = reason[1]
			if reason[0] == 'Date of birth':
				problems.append('Date of birth')
			if reason[0] == 'Picture':
				problems.append('Picture')
			if reason[0] == 'Height':
				problems.append('Height')
			if reason[0] == 'Weight':
				problems.append('Weight')
			if reason[0] == 'Backstory':
				if reason[1] == 'yes':
					continue
				elif reason[1] == 'wip':
					problems.append('WIP')
				else:
					problems.append('Backstory')
			if reason[0] == 'Name':
				problems.append('Name')
		f = open("InvalidCPList.txt", "a")
		problemen = ' + '.join(problems)
		f.write(f'{character_name} - {clink} - {problemen} - {link}\n')
		bericht += f"{problemen}\n{character_name} {clink} - PM'ed\n"
		f.close()
		if not 'Backstory' in problems and not 'WIP' in problems:
			themessage = message(name, character_name, problems)
			driver.get(f"https://www.dayzrp.com/messenger/compose/?to={id}")
			driver.find_element_by_name("messenger_title").send_keys("Incorrect CP")
			time.sleep(0.5)
			name = driver.find_element_by_class_name('cToken').text
			driver.find_element_by_css_selector('div.cke_wysiwyg_div.cke_reset.cke_enable_context_menu.cke_editable.cke_editable_themed.cke_contents_ltr').send_keys(themessage)
			# Add .click()
			driver.find_element_by_css_selector('button.ipsButton.ipsButton_primary').click()
			time.sleep(1)
		else:
			if not 'WIP' in problems:
				leftovers.append(name)
				layout = [[sg.Text('You still have to message: '+ name, justification='left')], [sg.Ok()]]
				window = sg.Window('Thanks', layout)
				event, values = window.read()
				window.close()
	# Add message to the forums.
	driver.get(f"https://www.dayzrp.com/forums/topic/86455-invalid-character-page-pms/#replyForm")
	driver.find_element_by_css_selector('div.ipsComposeArea_dummy.ipsJS_show').click()
	time.sleep(0.5)
	driver.find_element_by_css_selector('div.cke_wysiwyg_div.cke_reset.cke_enable_context_menu.cke_editable.cke_editable_themed.cke_contents_ltr').send_keys(bericht)
	layout = [[sg.Text('Did you finish editing the Invalid Character Page entry?\nBy clicking submit you will automatically submit.', justification='left')], [sg.Submit()]]
	window = sg.Window('Finished?', layout)
	event, values = window.read()
	window.close()
	# Add .click()
	driver.find_element_by_css_selector('button.ipsButton.ipsButton_primary').click()
	time.sleep(1)
	driver.close()